using AutoMapper;
using Microsoft.EntityFrameworkCore;
using WebApp.Controllers;
using WebApp.Data;
using WebApp.Helpers;
using WebApp.Models;
using WebApp.Service;
using Microsoft.AspNetCore.Mvc;
using WebApp.Dtos;

namespace WebApp_Test
{
    public class BasketControllerTest
    {
        private static DbContextOptions<DataContext> dbContextOptions = new DbContextOptionsBuilder<DataContext>()
                   .UseInMemoryDatabase(databaseName: "BasketDbControllerTest")
                   .Options;

        DataContext context;
        ProductsService productSerivce;
        CategoryService categoryService;
        IMapper _mapper;
        BasketController basketController;

        [OneTimeSetUp]
        public void Setup()
        {
            context = new DataContext(dbContextOptions);
            context.Database.EnsureCreated();

            SeedDatabase();

            productSerivce = new ProductsService(context);
            categoryService = new CategoryService(context);

            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new MappingProfiles());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }

            basketController = new BasketController(productSerivce, _mapper, categoryService);
        }

        [Test, Order(1)]
        public void HTTPOST_DiscountCalculateBasketItems_ReturnsOk_Discount_Calculate_BasketItems_Test()
        {
            List<BasketItem> basketItems = new List<BasketItem>();
            basketItems.Add(new BasketItem { Name= "Intel's Core i9-9900K", Price= Convert.ToDecimal(475.99), Quantity=2, Categories = new List<string> { "CPU" } });
            basketItems.Add(new BasketItem { Name= "Razer BlackWidow Keyboard", Price= Convert.ToDecimal(89.99), Quantity=1, Categories = new List<string> { "Keyboard ", "Periphery" } });

            var actionResult = basketController.DiscountCalculateBasketItems(basketItems).Result;
            
            Assert.That(actionResult.Result, Is.TypeOf<OkObjectResult>());
            var discountResponse = ((ObjectResult)actionResult.Result).Value;

            List<BasketItem>? basketItem = discountResponse as List<BasketItem> ?? null;
            BasketItem Item = basketItem[0];
            Assert.That(Convert.ToInt32(basketItem[0].Discount), Is.EqualTo(Convert.ToInt32(23.8)));


        }

        

        private void SeedDatabase()
        {
            var categories = new List<Category>
            {
                    new Category() {
                        Id = 1,
                        Name = "CPU"
                    },
                    new Category() {
                        Id = 2,
                        Name = "Keyboard"
                    },
                    new Category() {
                        Id = 3,
                        Name = "Periphery"
                    },
            };

            context.Categories.AddRange(categories);
            context.SaveChanges();

            var products = new List<Product>
            {
                    new Product() {
                        Id = 1,
                        Name = "Intel's Core i9-9900K",
                        Price = Convert.ToDecimal("475.99"),
                        Quantity = 10,

                    },
                    new Product() {
                        Id = 2,
                        Name = "Razer BlackWidow Keyboard",
                        Price = Convert.ToDecimal("89.99"),
                        Quantity = 50,
                    },
                    new Product() {
                        Id = 3,
                        Name = "Product 3",
                        Price = Convert.ToDecimal("1"),
                        Quantity = 1,
                    },
            };
            context.Products.AddRange(products);


            context.SaveChanges();
        }
    }
}