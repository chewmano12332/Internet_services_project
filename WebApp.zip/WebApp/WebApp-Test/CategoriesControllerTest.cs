using AutoMapper;
using Microsoft.EntityFrameworkCore;
using WebApp.Controllers;
using WebApp.Data;
using WebApp.Helpers;
using WebApp.Models;
using WebApp.Service;
using Microsoft.AspNetCore.Mvc;
using WebApp.Dtos;

namespace WebApp_Test
{
    public class CategoriesControllerTest
    {
        private static DbContextOptions<DataContext> dbContextOptions = new DbContextOptionsBuilder<DataContext>()
                   .UseInMemoryDatabase(databaseName: "CategoryDbControllerTest")
                   .Options;

        DataContext context;
        CategoryService categorySerivce;
        IMapper _mapper;
        CategoriesController categoriesController;
        ProductsService productSerivce;
        ProductsController productsController;

        [OneTimeSetUp]
        public void Setup()
        {
            context = new DataContext(dbContextOptions);
            context.Database.EnsureCreated();

            SeedDatabase();

            categorySerivce = new CategoryService(context);
            productSerivce = new ProductsService(context);

            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new MappingProfiles());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }

            categoriesController = new CategoriesController(categorySerivce, _mapper);
        }


        #region CategoryController Test Cases
        [Test, Order(1)]
        public void HTTPGET_GetCategories_ReturnsOk_Items_Count_Test()
        {
            var actionResult = categoriesController.GetCategories().Result;

            Assert.That(actionResult.Result, Is.TypeOf<OkObjectResult>());
            var categories = ((ObjectResult)actionResult.Result).Value;

            List<CategoryDto>? categoryList = categories as List<CategoryDto> ?? null;

            Assert.That(categoryList?.Count(), Is.EqualTo(3));
        }

        [Test, Order(2)]
        public void HTTPGET_GetCategoryById_ReturnsOk_Item_Check_Test()
        {
            var actionResult = categoriesController.GetCategory(1).Result;

            Assert.That(actionResult.Result, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult.Result).Value;
                        
            CategoryDto? category = value as CategoryDto ?? null;

            Assert.That(category?.Id, Is.EqualTo(1));

        }

        [Test, Order(3)]
        public void HTTPUT_PutCategory_ReturnsOk_Item_Update_Test()
        {
            CategoryDto categoryUpdate = new CategoryDto() { Id = 1, Description="New Category 1", Name= "New Category 1" };

            var actionResult = categoriesController.PutCategory(1, categoryUpdate).Result;

            Assert.That(actionResult, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult).Value;

           
            Assert.That(value, Is.EqualTo(1));

        }

        [Test, Order(4)]
        public void HTTPOST_PostCategory_ReturnsOk_Item_Insert_Test()
        {
            CategoryDto categoryNew = new CategoryDto() { Description = "New Category", Name = "New Category Insert" };

            var actionResult = categoriesController.PostCategory(categoryNew).Result;

            var value = ((ObjectResult)actionResult.Result).Value;

            CategoryDto? category = value as CategoryDto;

            Assert.IsTrue(category?.Id > 0);

        }

        [Test, Order(5)]
        public void HTTPDELETE_DeleteCategory_ReturnsOk_Item_Delete_Test()
        {            
            var actionResult = categoriesController.DeleteCategory(1).Result;

            Assert.That(actionResult, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult).Value;

            Assert.That(value, Is.EqualTo("Deleted successfully"));

        }

        #endregion
                       
        private void SeedDatabase()
        {
            var categories = new List<Category>
            {
                    new Category() {
                        Id = 1,
                        Name = "Category 1"
                    },
                    new Category() {
                        Id = 2,
                        Name = "Category 2"
                    },
                    new Category() {
                        Id = 3,
                        Name = "Category 3"
                    },
            };
            context.Categories.AddRange(categories);


            context.SaveChanges();

            var products = new List<Product>
            {
                    new Product() {
                        Id = 1,
                        Name = "Category 1"
                    },
                    new Product() {
                        Id = 2,
                        Name = "Category 2"
                    },
                    new Product() {
                        Id = 3,
                        Name = "Category 3"
                    },
            };
            context.Products.AddRange(products);


            context.SaveChanges();
        }
    }
}