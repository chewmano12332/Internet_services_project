using AutoMapper;
using Microsoft.EntityFrameworkCore;
using WebApp.Controllers;
using WebApp.Data;
using WebApp.Helpers;
using WebApp.Models;
using WebApp.Service;
using Microsoft.AspNetCore.Mvc;
using WebApp.Dtos;

namespace WebApp_Test
{
    public class ProductsControllerTest
    {
        private static DbContextOptions<DataContext> dbContextOptions = new DbContextOptionsBuilder<DataContext>()
                   .UseInMemoryDatabase(databaseName: "ProductDbControllerTest")
                   .Options;

        DataContext context;
        ProductsService productSerivce;
        IMapper _mapper;
        ProductsController productsController;

        [OneTimeSetUp]
        public void Setup()
        {
            context = new DataContext(dbContextOptions);
            context.Database.EnsureCreated();

            SeedDatabase();

            productSerivce = new ProductsService(context);

            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new MappingProfiles());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }

            productsController = new ProductsController(productSerivce, _mapper);
        }

        [Test, Order(1)]
        public void HTTPGET_GetProducts_ReturnsOk_Products_Count_Test()
        {
            var actionResult = productsController.GetProducts().Result;

            Assert.That(actionResult.Result, Is.TypeOf<OkObjectResult>());
            var products = ((ObjectResult)actionResult.Result).Value;

            List<ProductDto>? productList = products as List<ProductDto> ?? null;

            Assert.That(productList?.Count(), Is.EqualTo(3));
        }

        [Test, Order(2)]
        public void HTTPGET_GetProductById_ReturnsOk_Item_Check_Test()
        {
            var actionResult = productsController.GetProduct(1).Result;

            Assert.That(actionResult.Result, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult.Result).Value;

            ProductDto? product = value as ProductDto ?? null;

            Assert.That(product?.Id, Is.EqualTo(1));

        }

        [Test, Order(3)]
        public void HTTPUT_PutProduct_ReturnsOk_Item_Update_Test()
        {
            ProductDto productUpdate = new ProductDto() { Id = 1, Description = "New Product Test", Name = "New Product test des", Price = Convert.ToDecimal(50), Quantity = 100 };

            var actionResult = productsController.PutProduct(1, productUpdate).Result;

            Assert.That(actionResult, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult).Value;
           
            Assert.That(value, Is.EqualTo(1));

        }

        [Test, Order(4)]
        public void HTTPOST_PostProduct_ReturnsOk_Item_Insert_Test()
        {
            ProductDto productNew = new ProductDto() { Description = "New Product Insert Test", Name = "New Product insert test", Price = Convert.ToDecimal(20), Quantity = 30 };

            var actionResult = productsController.PostProduct(productNew).Result;

            var value = ((ObjectResult)actionResult.Result).Value;

            ProductDto? product = value as ProductDto;

            Assert.IsTrue(product?.Id > 0);

        }

        [Test, Order(5)]
        public void HTTPDELETE_DeleteProduct_ReturnsOk_Item_Delete_Test()
        {            
            var actionResult = productsController.DeleteProduct(1).Result;

            Assert.That(actionResult, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult).Value;

            Assert.That(value, Is.EqualTo("Deleted successfully"));

        }

        private void SeedDatabase()
        {
            var products = new List<Product>
            {
                    new Product() {
                        Id = 1,
                        Name = "Product 1"
                    },
                    new Product() {
                        Id = 2,
                        Name = "Product 2"
                    },
                    new Product() {
                        Id = 3,
                        Name = "Product 3"
                    },
            };
            context.Products.AddRange(products);


            context.SaveChanges();
        }
    }
}