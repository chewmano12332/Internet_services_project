using AutoMapper;
using Microsoft.EntityFrameworkCore;
using WebApp.Controllers;
using WebApp.Data;
using WebApp.Helpers;
using WebApp.Models;
using WebApp.Service;
using Microsoft.AspNetCore.Mvc;
using WebApp.Dtos;

namespace WebApp_Test
{
    public class StockControllerTest
    {
        private static DbContextOptions<DataContext> dbContextOptions = new DbContextOptionsBuilder<DataContext>()
                   .UseInMemoryDatabase(databaseName: "StockDbControllerTest")
                   .Options;

        DataContext context;
        ProductsService productSerivce;
        CategoryService categoryService;
        IMapper _mapper;
        StockController stockController;

        [OneTimeSetUp]
        public void Setup()
        {
            context = new DataContext(dbContextOptions);
            context.Database.EnsureCreated();

            SeedDatabase();

            productSerivce = new ProductsService(context);
            categoryService = new CategoryService(context);

            if (_mapper == null)
            {
                var mappingConfig = new MapperConfiguration(mc =>
                {
                    mc.AddProfile(new MappingProfiles());
                });
                IMapper mapper = mappingConfig.CreateMapper();
                _mapper = mapper;
            }
            
            stockController = new StockController(productSerivce, _mapper, categoryService);
        }

        [Test, Order(1)]
        public void HTTPOST_UpdateStock_ReturnsOk_Update_Stock_Test()
        {
            List<ProductStock> productStock = new List<ProductStock>();
            string[] categories = new string[2] {"Test Cat 1", "Test Cat 2"};
            productStock.Add(new ProductStock { Name = "Test", Price = 50, Quantity = 20, Categories = categories });

            var actionResult = stockController.UpdateStock(productStock).Result;
                       
            Assert.That(actionResult, Is.TypeOf<OkObjectResult>());
            var value = ((ObjectResult)actionResult).Value;

            Assert.That(value, Is.EqualTo("Stock updated successfully."));

        }

        

        private void SeedDatabase()
        {
            var categories = new List<Category>
            {
                    new Category() {
                        Id = 1,
                        Name = "Category 1"
                    },
                    new Category() {
                        Id = 2,
                        Name = "Category 2"
                    },
                    new Category() {
                        Id = 3,
                        Name = "Category 3"
                    },
            };

            context.Categories.AddRange(categories);


            var products = new List<Product>
            {
                    new Product() {
                        Id = 1,
                        Name = "Product 1"
                    },
                    new Product() {
                        Id = 2,
                        Name = "Product 2"
                    },
                    new Product() {
                        Id = 3,
                        Name = "Product 3"
                    },
            };
            context.Products.AddRange(products);


            context.SaveChanges();
        }
    }
}