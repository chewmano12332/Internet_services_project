﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using WebApp.Models;
using AutoMapper;
using WebApp.Service;

namespace WebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class BasketController : ControllerBase
    {
        private readonly IProductsSerivce _productService;
        private readonly ICategoryService _categoryService;
        private readonly IMapper _mapper;

        public BasketController(IProductsSerivce productService, IMapper mapper, ICategoryService categoryService)
        {
            _productService = productService;
            _mapper = mapper;
            _categoryService = categoryService;
        }

        // POST: api/Basket
        [HttpPost]
        public async Task<ActionResult<IEnumerable<BasketItem>>> DiscountCalculateBasketItems(List<BasketItem> basketItems)
        {
            if (basketItems.Count == 1)
            {
                return Ok(basketItems);
            }            

            int itemIndex = 0;            
            foreach (var item in basketItems)
            {
                var product = await _productService.GetProductByName(item.Name);

                itemIndex = basketItems.FindIndex(x => x.Name == item.Name);

                if (product == null)
                {
                    return Problem($"No Product '{item.Name}' Found.");
                }                                

                if (product.Quantity < item.Quantity) // stock check in database vs basket item qty
                {
                    return Problem($"Shopping cart is invalid because there are not enough product '{item.Name}' in stock");
                }

                decimal discount = 0;

                if (item.Quantity == 1 && IsSameCategoryExists(basketItems, item.Categories, item.Name)) // 5% perc will apply on same category items and more than one product of same category
                {
                    discount = Math.Round(Convert.ToDecimal(((double)5 /100) * (double)item.Price), 2);
                }
                else if (item.Quantity > 1) // 5% perc will apply on only first item or 5% will equally divided on each item.
                {
                    discount = Math.Round(Convert.ToDecimal(((double)5 / 100) * (double)item.Price), 2);

                }

                basketItems[itemIndex].Discount = discount;

            }

            return Ok(basketItems);
        }

        private bool IsSameCategoryExists(List<BasketItem> basketItems, List<string> findcategories, string itemName)
        {
            foreach (var findCat in findcategories)
            {
                foreach (var item in basketItems)
                {
                    foreach (var cat in item.Categories)
                    {
                        if (itemName == item.Name)
                        {
                            continue;
                        }

                        if (cat == findCat)
                        {
                            return true;
                        }
                    }

                }
            }
            
            return false;
        }

    }
}
