﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp.Data;
using WebApp.Models;
using AutoMapper;
using WebApp.Dtos;
using WebApp.Service;

namespace WebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class CategoriesController : ControllerBase
    {
        
        private readonly IMapper _mapper;
        private readonly ICategoryService _categoryService;

        public CategoriesController(ICategoryService categoryService, IMapper mapper)
        {
            _categoryService = categoryService;
            _mapper = mapper;
        }

        // GET: api/Categories
        [HttpGet]
        public async Task<ActionResult<IEnumerable<CategoryDto>>> GetCategories()
        {
            var categories = await _categoryService.GetAllCategories();

            return Ok(_mapper.Map<List<CategoryDto>>(categories));
        }



        // GET: api/Categories/5
        [HttpGet("{id}")]
        public async Task<ActionResult<CategoryDto>> GetCategory(int id)
        {
            var category = await _categoryService.GetCategory(id);

            if (category == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<CategoryDto>(category));
        }


        // PUT: api/Categories/5        
        [HttpPut("{id}")]
        public async Task<IActionResult> PutCategory(int id, CategoryDto category)
        {

            if (id <= 0)
            {
                return BadRequest();
            }

            var value = await _categoryService.UpdateCategory(id, category);

            if (value > 0)
            {
                return Ok(value);
            }
            else
            {
                return NotFound("An error occured.");
            }

        }

        // POST: api/Categories        
        [HttpPost]
        public async Task<ActionResult<CategoryDto>> PostCategory(CategoryDto category)
        {
            if (category == null)
            {
                return BadRequest();
            }

            var value = await _categoryService.InsertCategory(category);

            if (value > 0)
            {
                category.Id = value;
                return Ok(category);
            }
            else
            {
                return NotFound("An error occured.");
            }
        }

        // DELETE: api/Categories/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteCategory(int id)
        {
            if (id <= 0)
            {
                return BadRequest();
            }

            var value = await _categoryService.DeleteCategory(id);

            if (value > 0)
            {
                return Ok("Deleted successfully");
            }
            else
            {
                return NotFound("An error occured.");
            }
        }

    }
}
