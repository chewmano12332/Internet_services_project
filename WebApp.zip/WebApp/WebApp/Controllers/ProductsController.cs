﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp.Data;
using WebApp.Models;
using AutoMapper;
using WebApp.Dtos;
using WebApp.Service;

namespace WebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class ProductsController : ControllerBase
    {
        private readonly IProductsSerivce _productService;
        private readonly IMapper _mapper;

        public ProductsController(IProductsSerivce productService, IMapper mapper)
        {
            _productService = productService;
            _mapper = mapper;
        }

        // GET: api/Products
        [HttpGet]
        public async Task<ActionResult<IEnumerable<ProductDto>>> GetProducts()
        {
            var products = await _productService.GetAllProducts();

            return Ok(_mapper.Map<IEnumerable<ProductDto>>(products));
        }

        // GET: api/Products/5
        [HttpGet("{id}")]
        public async Task<ActionResult<ProductDto>> GetProduct(int id)
        {            
            var product = await _productService.GetProductById(id);

            if (product == null)
            {
                return NotFound();
            }

            return Ok(_mapper.Map<ProductDto>(product)); 

        }

        // PUT: api/Products/5
        [HttpPut("{id}")]
        public async Task<IActionResult> PutProduct(int id, ProductDto product)
        {
            if (id <= 0)
            {
                return BadRequest();
            }

            var value = await _productService.UpdateProduct(id, product);

            if (value > 0)
            {
                return Ok(value);
            }
            else
            {
                return NotFound("An error occured.");
            }
           
        }

        // POST: api/Products
        [HttpPost]
        public async Task<ActionResult<ProductDto>> PostProduct(ProductDto product)
        {
            if (product == null)
            {
                return BadRequest();
            }

            var value = await _productService.InsertProduct(product);
            

            if (value > 0)
            {
                product.Id = value;
                return Ok(product);
            }
            else
            {
                return NotFound("An error occured.");
            }


        }

        // DELETE: api/Products/5
        [HttpDelete("{id}")]
        public async Task<IActionResult> DeleteProduct(int id)
        {
            if (id <= 0)
            {
                return BadRequest();
            }

            var value = await _productService.DeleteProduct(id);

            if (value > 0)
            {
                return Ok("Deleted successfully");
            }
            else
            {
                return NotFound("An error occured.");
            }

          
        }


    }
}
