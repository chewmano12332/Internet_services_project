﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using AutoMapper;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using WebApp.Data;
using WebApp.Dtos;
using WebApp.Models;
using WebApp.Service;

namespace WebApp.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StockController : ControllerBase
    {
        private readonly IProductsSerivce _productService;
        private readonly ICategoryService _categoryservice;
        private readonly IMapper _mapper;

        public StockController(IProductsSerivce productService, IMapper mapper, ICategoryService categoryservice)
        {
            _productService = productService;
            _mapper = mapper;
            _categoryservice = categoryservice;
        }


        // POST: api/UpdateStock
        [HttpPost]
        public async Task<IActionResult> UpdateStock(List<ProductStock> productStock)
        {
            foreach (var stock in productStock)
            {
                var product = await _productService.GetProductByName(stock.Name);
                var productItem = _mapper.Map<ProductDto>(product);
                int productItemId = 0;

                if (product == null) // update stock as  a new record
                {
                    ProductDto newProduct = new ProductDto { Name = stock.Name, Price = stock.Price, Quantity = stock.Quantity };
                    productItemId = await _productService.InsertProduct(newProduct);
                    productItem = newProduct;
                    productItem.Id = productItemId;
                }
                else
                {
                    productItemId = productItem.Id.Value;
                    productItem.Quantity = stock.Quantity; // update stock in existing item
                    await _productService.UpdateProduct(productItemId, productItem);
                }

                foreach (var catName in stock.Categories)
                {
                    var category = await _categoryservice.GetCategoryByName(catName);
                    CategoryDto categoryItem;

                    if (category == null)
                    {
                        Category newCategory = new Category { Name = catName };
                        var newCategoryitem = _mapper.Map<CategoryDto>(newCategory);
                        int catid = await _categoryservice.InsertCategory(newCategoryitem);
                        categoryItem = newCategoryitem;
                        categoryItem.Id = catid;

                    }
                    else
                    {
                        categoryItem = _mapper.Map<CategoryDto>(category);
                    }
                    

                    var productCategoryItem = await _productService.GetProductCategoryByPIdAndCatId(productItem.Id, categoryItem.Id);

                    if (productCategoryItem == null)
                    {
                        var productCategoryObj = new ProductCategory() { CategoryId = categoryItem.Id, ProductId = productItem.Id.Value };

                        await _productService.InsertProductCategory(productCategoryObj);

                    }                       

                }

            }

            return Ok("Stock updated successfully.");
        }

    }
}
