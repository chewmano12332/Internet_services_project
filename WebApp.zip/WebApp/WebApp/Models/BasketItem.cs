﻿using System.ComponentModel.DataAnnotations.Schema;
namespace WebApp.Models
{
    [NotMapped]
    public class BasketItem
    {
        public string Name { get; set; }

        public int Quantity { get; set; }

        public decimal Price { get; set; }

        public List<string> Categories { get; set; }

        public decimal? Discount { get; set; }

    }
}
