﻿using System.ComponentModel.DataAnnotations.Schema;

namespace WebApp.Models
{
    [NotMapped]
    public class ProductStock
    {
        public string Name { get; set; }

        public decimal Price { get; set; }

        public int? Quantity { get; set; }

        public string[] Categories { get; set; }
    }
}
