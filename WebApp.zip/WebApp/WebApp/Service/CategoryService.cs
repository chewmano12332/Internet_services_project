﻿using WebApp.Dtos;
using WebApp.Models;

namespace WebApp.Service
{
    public class CategoryService : ICategoryService
    {
        private DataContext _context;
        public CategoryService(DataContext context)
        {
            _context = context;
        }

        public async  Task<IList<Category>> GetAllCategories()
        {
            return await _context.Categories.ToListAsync();
        }

        public async Task<Category> GetCategory(int id)
        {
            var category =  await _context.Categories.FirstOrDefaultAsync(p => p.Id == id);
            if (category == null)
            {
                return null;
            }
            return category;
        }

        public async Task<Category> GetCategoryByName(string name)
        {
            var category = await _context.Categories.FirstOrDefaultAsync(p => p.Name == name);
            if (category == null)
            {
                return null;
            }
            return category;
        }

        public async Task<int> InsertCategory(CategoryDto category)
        {
            var categoryObj = new Category()
            {
                Name = category.Name,  
                Description = category.Description
                
            };
            _context.Categories.Add(categoryObj);
            await _context.SaveChangesAsync();

            return categoryObj.Id;
        }

        public async Task<int> UpdateCategory(int categoryId, CategoryDto category)
        {
            var categoryObj = await _context.Categories.FirstOrDefaultAsync(p => p.Id == categoryId);
            if (categoryObj != null)
            {
                categoryObj.Description = category.Description;
                categoryObj.Name = category.Name;   
                _context.Entry(categoryObj).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }

            return categoryObj != null ? categoryObj.Id : 0;


        }

        public async Task<int> DeleteCategory(int id)
        {
            var category = await _context.Categories.FindAsync(id);
            if (category != null)
            {
                _context.Categories.Remove(category);
                return await _context.SaveChangesAsync();
            }

            return 0;
           
        }

        
    }
}
