﻿using WebApp.Dtos;
using WebApp.Models;

namespace WebApp.Service
{
    public interface ICategoryService
    {
        Task<IList<Category>> GetAllCategories();
        Task<Category> GetCategory(int id);
        Task<Category> GetCategoryByName(string name);
        Task<int> InsertCategory(CategoryDto category);
        Task<int> UpdateCategory(int categoryId, CategoryDto category);
        Task<int> DeleteCategory(int id);
    }
}
