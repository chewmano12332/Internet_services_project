﻿using WebApp.Dtos;
using WebApp.Models;

namespace WebApp.Service
{
    public interface IProductsSerivce
    {
        Task<IList<Product>> GetAllProducts();
        Task<Product> GetProductById(int id);
        Task<Product> GetProductByName(string name);
        Task<ProductCategory> GetProductCategoryByPIdAndCatId(int? productId, int? categoryId);
        Task<int> InsertProductCategory(ProductCategory productcategory);
        Task<int> InsertProduct(ProductDto product);
        Task<int> UpdateProduct(int productId, ProductDto product);
        Task<int> DeleteProduct(int id);
    }
}
