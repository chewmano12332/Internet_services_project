﻿using WebApp.Dtos;
using WebApp.Models;

namespace WebApp.Service
{
    public class ProductsService : IProductsSerivce
    {
        private DataContext _context;
        public ProductsService(DataContext context)
        {
            _context = context;
        }

        public async Task<IList<Product>> GetAllProducts()
        {
            return await _context.Products.ToListAsync();
        }

        public async Task<Product> GetProductById(int id)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.Id == id);
            if (product == null)
            {
                return null;
            }
            return product;
        }

        public async Task<Product> GetProductByName(string name)
        {
            var product = await _context.Products.FirstOrDefaultAsync(p => p.Name == name);
            if (product == null)
            {
                return null;
            }
            return product;
        }

        public async Task<ProductCategory> GetProductCategoryByPIdAndCatId(int? productId, int? categoryId)
        {
            if (productId == null || productId == 0 )
            {
                return null;
            }

            if (categoryId == null || categoryId == 0)
            {
                return null;
            }


            var productcategory = await _context.ProductCategories.FirstOrDefaultAsync(p => p.ProductId == productId && p.CategoryId == categoryId);

            if (productcategory == null)
            {
                return null;
            }
            return productcategory;

        }

        public async Task<int> InsertProduct(ProductDto product)
        {
            var productObj = new Product()
            {
                Name = product.Name,
                Description = product.Description,
                Price = product.Price,
                Quantity = product.Quantity

            };
            _context.Products.Add(productObj);
            await _context.SaveChangesAsync();

            return productObj.Id;
        }

        public async Task<int> InsertProductCategory(ProductCategory productcategory)
        {            
            _context.ProductCategories.Add(productcategory);
            await _context.SaveChangesAsync();

            return productcategory.ProductCategoryId;
        }

        public async Task<int> UpdateProduct(int productId, ProductDto product)
        {
            var productObj = await _context.Products.FirstOrDefaultAsync(p => p.Id == productId);
            if (productObj != null)
            {   
                productObj.Price = product.Price;
                productObj.Quantity = product.Quantity; 
                productObj.Description = product.Description;
                productObj.Name = product.Name;
                

                _context.Entry(productObj).State = EntityState.Modified;
                await _context.SaveChangesAsync();
            }

            return productObj != null ? productObj.Id : 0;


        }

        public async Task<int> DeleteProduct(int id)
        {
            var product = await _context.Products.FindAsync(id);
            if (product != null)
            {
                _context.Products.Remove(product);
                return await _context.SaveChangesAsync();
            }

            return 0;

        }


    }
}
